// import useGetProfile from "./../../utils/useGetProfile";
const Profile = () => {
  // let user = useGetProfile();
  // console.log(user);
  return <div>Profile</div>;
};

export default Profile;
